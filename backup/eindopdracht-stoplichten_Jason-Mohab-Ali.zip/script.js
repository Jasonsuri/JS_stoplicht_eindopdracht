var werken;
var buitenwerking;
var stoplicht1 = document.getElementById("stoplicht1");
var stoplicht2 = document.getElementById("stoplicht2");
var rijden;
var auto1 = document.getElementById('auto1');
var auto2 = document.getElementById('auto2');
auto1.style.position = 'absolute';
auto1.style.left = '800px';
auto1.style.top = '500px';
auto2.style.position = 'absolute';
auto2.style.right = '850px';
auto2.style.bottom = '500px';

function starten() {
    auto1.style.top = parseInt(auto1.style.top) - 5 + 'px';
    auto2.style.bottom = parseInt(auto2.style.bottom) - 5 + 'px';
    rijden = setTimeout(starten, 10);
}
function stop() {
    clearTimeout(rijden)
}
function opnieuw() {
    clearTimeout(rijden);
    auto1.style.top = '500px';
    auto2.style.top = '0px'
}

function aanzetten() {
    clearTimeout(buitenwerking);
    maakRood();
    werken = setTimeout(maakGroen, 4000);
    werken = setTimeout(maakOranje, 8000);
    werken = setTimeout(aanzetten, 10000);

}

function knipperen() {
    clearTimeout(werken);
    maakOranje();
    buitenwerking = setTimeout(zetUit, 500);
    buitenwerking = setTimeout(knipperen, 1000);

}
function uitzetten() {
    zetUit();
    clearTimeout(buitenwerking);
    clearTimeout(werken);
}

function maakRood() {
    stoplicht1.src = "images/stoplicht_rood.png";
    stoplicht2.src = "images/stoplicht_rood.png";
}
function maakGroen() {
    stoplicht1.src = "images/stoplicht_groen.png";
    stoplicht2.src = "images/stoplicht_groen.png";
}
function maakOranje() {
    stoplicht1.src = "images/stoplicht_oranje.png";
    stoplicht2.src = "images/stoplicht_oranje.png";
}
function zetUit() {
    stoplicht1.src = "images/stoplicht_uit.png";
    stoplicht2.src = "images/stoplicht_uit.png";
}


/*
function veranderStoplicht() {

    if (stoplicht.src.match("stoplicht_rood")){
        stoplicht.src = "images/stoplicht_groen.png";
    } else {
        stoplicht.src = "images/stoplicht_rood.png"
    }
}*/
